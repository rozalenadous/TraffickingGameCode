using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class showInsta : MonoBehaviour
{
 public Image imageToDisplay;

 void OnEnable(){

        imageToDisplay.enabled = true;
        
    }
}
