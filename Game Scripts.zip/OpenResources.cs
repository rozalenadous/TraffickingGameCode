using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenResources : MonoBehaviour
{
    public void open(){
      Application.OpenURL("https://htsresources.carrd.co/");
    }
}
